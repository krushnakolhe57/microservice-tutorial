package com.rate.servise;

import java.util.List;

import com.rate.entity.Rate;

public interface RatingServise {
	
	Rate createRating(Rate rate);
	List<Rate> getRating();
	List<Rate> getRatingByCustomerId(String customerId);
	List<Rate> getRatingByHotelId(String hotelId);
	
}
