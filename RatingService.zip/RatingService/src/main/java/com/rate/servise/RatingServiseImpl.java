package com.rate.servise;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rate.entity.Hotel;
import com.rate.entity.Rate;
import com.rate.exception.RatingException;
import com.rate.externalservise.HotelService;
import com.rate.repository.RatingRepository;

@Service
public class RatingServiseImpl implements RatingServise{

	@Autowired
	private RatingRepository ratingRepository;
	
	@Autowired
	private HotelService hotelService;
	
	@Override
	public Rate createRating(Rate rate) {
		
		if(rate!=null) {
		rate.setRatingId(UUID.randomUUID().toString());
			return this.ratingRepository.save(rate);
		}else {
			throw new RatingException("Rating  is Null");
		}
	}

	@Override
	public List<Rate> getRating() {
	
		List<Rate> list =  this.ratingRepository.findAll();
		
		List<Rate> ratingList 	= list.stream().map(  rating -> {

			Hotel hotel = hotelService.getHotel(rating.getHotelId());
			
			rating.setHotel(hotel);
			return rating;
		}).collect(Collectors.toList());
		
		return ratingList;
	}

	
	@Override
	public List<Rate> getRatingByHotelId(String hotelId) {
		
		if(hotelId!=null) {
			List<Rate> list =  this.ratingRepository.findByHotelId(hotelId);

			List<Rate> ratingList 	= list.stream().map(  rating -> {

				Hotel hotel = hotelService.getHotel(rating.getHotelId());
				
				rating.setHotel(hotel);
				return rating;
			}).collect(Collectors.toList());
			
			return ratingList;
		}else {
			throw new RatingException("hotelId is Null");
		}
	}

	@Override
	public List<Rate> getRatingByCustomerId(String customerId) {
		if(customerId!=null) {
			
			List<Rate> list =  this.ratingRepository.findByCustomerId(customerId);
			
			List<Rate> ratingList 	= list.stream().map(  rating -> {

				Hotel hotel = hotelService.getHotel(rating.getHotelId());
				
				rating.setHotel(hotel);
				return rating;
			}).collect(Collectors.toList());
			
			return ratingList;
		}else {
			throw new RatingException("customerId is Null");
		}
	}

}
