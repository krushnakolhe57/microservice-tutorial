package com.rate.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
public class Rate {
	
	    @Id
		private String ratingId;
		private String customerId;
		private String hotelId;
		private int rating;
		private String feedback;
		
		@Transient
		private Hotel hotel;
}
