package com.rate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rate.entity.Rate;
import java.util.List;


@Repository
public interface RatingRepository extends JpaRepository<Rate, String> {
	
	List<Rate> findByCustomerId(String customerId);
	List<Rate> findByHotelId(String hotelId);
	
	
	

}
