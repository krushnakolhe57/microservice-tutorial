package com.rate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rate.entity.Rate;
import com.rate.servise.RatingServise;

@RestController
@RequestMapping("/rate")
public class RatingContoller {
	
	@Autowired
	private RatingServise ratingServise;
	
	@PostMapping("/create")
	public ResponseEntity<Rate> createRating(@RequestBody Rate rate){
		
		Rate rate2 = this.ratingServise.createRating(rate);
		return ResponseEntity.status(HttpStatus.CREATED).body(rate2);	
	}
	
	
	@GetMapping("/all")
	public ResponseEntity<List<Rate>> getRating(){
		
		List<Rate> rate = this.ratingServise.getRating();
		
		return ResponseEntity.ok(rate);
		
	}
	
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<Rate>> getRatingByCustomerId(@PathVariable("customerId") String customerId){
		
		List<Rate> rate = this.ratingServise.getRatingByCustomerId(customerId);
		
		return ResponseEntity.ok(rate);
		
	}
	
	@GetMapping("/hotel/{hotelId}")
	public ResponseEntity<List<Rate>> getRatingByHotelId(@PathVariable("hotelId") String hotelId){
		
		List<Rate> rate = this.ratingServise.getRatingByHotelId(hotelId);
		
		return ResponseEntity.ok(rate);
		
	}
}
