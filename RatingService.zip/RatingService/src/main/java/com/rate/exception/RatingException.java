package com.rate.exception;


public class RatingException extends RuntimeException {
	
	
	public RatingException() {
		super("Not Found Rating");
	}
	
	public RatingException(String msg) {
		super();
	}
	

}
