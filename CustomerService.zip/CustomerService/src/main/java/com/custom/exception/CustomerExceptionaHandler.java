package com.custom.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CustomerExceptionaHandler {
	
	@ExceptionHandler(CustomerException.class)
	public ResponseEntity<ApiResponce> exceptionHandler(CustomerException ex){
		
		String massage = ex.getMessage();
		
		ApiResponce response =  ApiResponce.builder().massage(massage).success(true).status(HttpStatus.NOT_FOUND).build();
		
		return new ResponseEntity<ApiResponce>(response , HttpStatus.NOT_FOUND);
		
	}

}
