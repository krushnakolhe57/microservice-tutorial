package com.custom.exception;

public class CustomerException extends RuntimeException{
	
	public CustomerException() {
		super("Resource Not found on server");
	
	}
	
	public CustomerException( String msg) {
		super(msg);
	}

}
