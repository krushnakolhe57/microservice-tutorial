package com.custom.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.custom.entity.Customer;
import com.custom.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/all")
	public List<Customer> getCustomers(){
		return this.customerService.getAllCustomer();
	}

	@PostMapping("/add")
	public Customer addCustomer (@RequestBody Customer customer) {
		return this.customerService.addCustomer(customer);
	}
	
	@GetMapping("/{customerId}")
	public Customer getById(@PathVariable("customerId") String customerId) {
		return this.customerService.findByCustomerId(customerId);
	}
	
	
	@DeleteMapping("/delete/{customerId}")
	public String delete(@PathVariable("customerId") String customerId) {
		
		if(this.customerService.deleteByid(customerId)) {
			return "Deleted";
		}
		return "Not Deleted";
		
	}

}
