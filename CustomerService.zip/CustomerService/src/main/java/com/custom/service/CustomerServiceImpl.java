package com.custom.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.custom.entity.Customer;
import com.custom.entity.Hotel;
import com.custom.entity.Rate;
import com.custom.externalService.HotelService;
import com.custom.externalService.RatingService;
import com.custom.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private HotelService hotelService;

	@Autowired
	private RatingService ratingService;

	@Override
	public List<Customer> getAllCustomer() {
		List<Customer> allCustomers = this.customerRepository.findAll();
		
		allCustomers.forEach(customer -> {
//			Rate[] ratingArray =	this.restTemplate.getForObject("http://RATING-SERVICE/rate/customer/"+customer.getCustomerId() , Rate[].class);
//			List<Rate> list =  Arrays.stream(ratingArray).toList();
			
			List<Rate> list =  ratingService.getCustomerRating(customer.getCustomerId());

			List<Rate> ratingList 	= list.stream().map(  rating -> {

				Hotel hotel = hotelService.getHotel(rating.getHotelId());
//						restTemplate.getForEntity( "http://HOTEL-SERVICE/hotel/"+rating.getHotelId(), Hotel.class).getBody();
				
				rating.setHotel(hotel);
				return rating;
			}).collect(Collectors.toList());
		
			customer.setRates(ratingList);
	        
	    });
		return allCustomers;
	}

	@Override
	public Customer findByCustomerId(String customerId) {
		
		Customer customer = this.customerRepository.findByCustomerId(customerId);
		
//		http://localhost:8085/rate/customer/5aacd6dd-d51e-4bab-be11-c198dc5d4e85
		
//		Rate[] ratingArray =	this.restTemplate.getForObject("http://RATING-SERVICE/rate/customer/"+customerId , Rate[].class);
		
//		List<Rate> list =  Arrays.stream(ratingArray).toList();
		List<Rate> list =  ratingService.getCustomerRating(customer.getCustomerId());

		List<Rate> ratingList 	= list.stream().map(  rating -> {
//		http://localhost:8082/hotel/b221b573-b6b2-4f0f-a5b4-da30ce721fb4	
			
			Hotel hotel = hotelService.getHotel(rating.getHotelId());
//					restTemplate.getForEntity( "http://HOTEL-SERVICE/hotel/"+rating.getHotelId(), Hotel.class).getBody();
			
			rating.setHotel(hotel);
			return rating;
		}).collect(Collectors.toList());
	
		customer.setRates(ratingList);
		
		return customer;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		
		customer.setCustomerId(UUID.randomUUID().toString());
		return this.customerRepository.save(customer);
	}

	@Override
	public boolean deleteByid(String customerId) {
		
		if(customerId!=null) {
			this.customerRepository.deleteById(customerId);
			return true;
		}else {
			return false;
		} 
	}
}
