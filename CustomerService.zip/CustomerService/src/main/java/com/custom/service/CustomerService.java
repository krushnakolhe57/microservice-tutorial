package com.custom.service;

import java.util.List;
import java.util.Optional;

import com.custom.entity.Customer;


public interface CustomerService {
	
    List<Customer> getAllCustomer();
	Customer findByCustomerId(String customerId) ;
	Customer  addCustomer(Customer customer) ;
	 boolean deleteByid(String customerId) ;

	
}
