package com.custom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerServiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
