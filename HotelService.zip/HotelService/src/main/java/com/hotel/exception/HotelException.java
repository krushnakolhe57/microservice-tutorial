package com.hotel.exception;

public class HotelException extends RuntimeException{
	
	
	public HotelException() {
		super("Not Found");
	}
	
	public HotelException(String msg) {
		super(msg);
	}

}
