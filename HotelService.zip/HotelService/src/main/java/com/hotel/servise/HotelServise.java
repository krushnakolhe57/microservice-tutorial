package com.hotel.servise;

import java.util.List;
import java.util.Optional;

import com.hotel.entity.Hotel;

public interface HotelServise {
	
	Optional<Hotel> addHotel(Hotel hotel);
	
	Optional<List<Hotel>> getAllHotel();
	
	Optional<Hotel> getHotel(String hotelId);
	
	void deleteHotel(String hotelId);

}
