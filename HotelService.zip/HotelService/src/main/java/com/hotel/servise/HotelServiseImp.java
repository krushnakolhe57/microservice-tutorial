package com.hotel.servise;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.entity.Hotel;
import com.hotel.reposotory.HotelRepository;


@Service
public class HotelServiseImp  implements HotelServise{
	
	@Autowired
	private HotelRepository hotelRepository;

	@Override
	public Optional<Hotel> addHotel(Hotel hotel) {
		
		hotel.setHotelId(UUID.randomUUID().toString());
		
	Hotel h1 = this.hotelRepository.save(hotel);
		
		return Optional.of(h1);
	}

	@Override
	public Optional<List<Hotel> >getAllHotel() {
		
		Optional<List<Hotel> > allHotel = 
		
		Optional.of(this.hotelRepository.findAll());
	
		if(allHotel.isEmpty()) {
			return null;
		}
		return allHotel;
	}

	@Override
	public Optional<Hotel> getHotel(String hotelId) {
		
		if(hotelId!=null) {
			return this.hotelRepository.findById(hotelId);
		}
		return null;
		
	}

	@Override
	public void deleteHotel(String hotelId) {
		if(hotelId!=null) {
			 this.hotelRepository.deleteById(hotelId);
		}
		
	}

}
