package com.hotel.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.entity.Hotel;
import com.hotel.servise.HotelServise;

@RestController
@RequestMapping("/hotel")
public class HotelController {
	
	@Autowired
	private HotelServise hotelServise;
	
	@PostMapping("/add")
	public String addHotel(@RequestBody Hotel hotel) {
		
		this.hotelServise.addHotel(hotel);
		return "Hotel Add Successfully";
	}
	
	@GetMapping("/all")
	public Optional<List<Hotel>> getAllHotel(){
		return this.hotelServise.getAllHotel();
	}
	
	@GetMapping("/{hotelId}")
	public Optional<Hotel> getHotel(@PathVariable("hotelId") String hotelId){
		return this.hotelServise.getHotel(hotelId);
		
	}
	
	@DeleteMapping("/{hotelId}")
	public String delete( @PathVariable("hotelId") String hotelId) {
		this.hotelServise.deleteHotel(hotelId);
		return "Deleted";
	}
	
	

}
