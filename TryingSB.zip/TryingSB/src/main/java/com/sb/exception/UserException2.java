package com.sb.exception;

public class UserException2  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8254932145316333085L;

	public UserException2(String message) {
		super(message);
	}
	
	

}
