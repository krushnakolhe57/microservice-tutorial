package com.sb.exception;

public class UserException  extends Exception {

	private static final long serialVersionUID = -203113939127024433L;


	public UserException(String message) {
		super(message);
	
	}


}
